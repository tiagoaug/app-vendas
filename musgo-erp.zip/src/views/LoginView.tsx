import React, { useState } from "react";
import { auth, signInWithGoogle } from "../lib/firebase";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { Eye, EyeOff, Mail, Lock } from "lucide-react";

export default function LoginView() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (isRegistering) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleGoogleLogin = async () => {
    setError(null);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      if (err.code === 'auth/cancelled-popup-request') {
        setError('Login cancelado.');
      } else {
        setError(err.message);
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950 p-6">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 p-8 rounded-[2rem] shadow-xl border border-slate-100 dark:border-slate-800">
        <h1 className="text-2xl font-black text-center mb-6 text-slate-800 dark:text-white uppercase tracking-tighter">Entrar</h1>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="email"
              placeholder="Seu e-mail"
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 border-none text-slate-800 dark:text-white"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Sua senha"
              className="w-full pl-10 pr-10 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 border-none text-slate-800 dark:text-white"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
          
          {error && <p className="text-red-500 text-xs text-center">{error}</p>}
          
          <button 
            type="submit"
            className="w-full bg-indigo-600 text-white font-black py-3 rounded-xl uppercase tracking-widest hover:bg-indigo-700 transition"
          >
            {isRegistering ? "Cadastrar" : "Entrar"}
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-slate-400 font-bold uppercase tracking-widest cursor-pointer" onClick={() => setIsRegistering(!isRegistering)}>
          {isRegistering ? "Já tem uma conta? Entrar" : "Não tem conta? Cadastrar"}
        </div>

        <div className="mt-8">
          <button
            onClick={handleGoogleLogin}
            className="w-full bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold py-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition mt-2"
          >
            Entrar com Google
          </button>
        </div>
      </div>
      <p className="mt-6 text-[10px] text-slate-400 text-center max-w-xs">
        Nota: Para e-mail e senha funcionarem, certifique-se de que o provedor esteja habilitado no Console do Firebase.
      </p>
    </div>
  );
}
